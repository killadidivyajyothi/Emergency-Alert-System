"""
Emergency Alert System (Streamlit single-file app)
Save as: app.py
Run: pip install streamlit pandas sqlite3-binary
Then: streamlit run app.py
"""

import streamlit as st
import sqlite3
from datetime import datetime
import pandas as pd
import io

# ---------------------------
# Database (SQLite) functions
# ---------------------------
DB_PATH = "alerts.db"

def init_db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    c = conn.cursor()
    c.execute(
        """CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            severity TEXT NOT NULL,
            area TEXT,
            created_at TEXT NOT NULL,
            scheduled_at TEXT,
            status TEXT NOT NULL
        )"""
    )
    conn.commit()
    return conn

conn = init_db()

def insert_alert(title, message, severity, area, scheduled_at, status="Draft"):
    c = conn.cursor()
    created_at = datetime.utcnow().isoformat()
    c.execute(
        "INSERT INTO alerts (title, message, severity, area, created_at, scheduled_at, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (title, message, severity, area, created_at, scheduled_at, status),
    )
    conn.commit()
    return c.lastrowid

def update_alert_status(alert_id, status):
    c = conn.cursor()
    c.execute("UPDATE alerts SET status = ? WHERE id = ?", (status, alert_id))
    conn.commit()

def fetch_alerts(where_clause=None, params=()):
    c = conn.cursor()
    query = "SELECT id, title, message, severity, area, created_at, scheduled_at, status FROM alerts"
    if where_clause:
        query += " WHERE " + where_clause
    query += " ORDER BY created_at DESC"
    c.execute(query, params)
    rows = c.fetchall()
    cols = ["id", "title", "message", "severity", "area", "created_at", "scheduled_at", "status"]
    return pd.DataFrame(rows, columns=cols)

# ---------------------------
# Simulated send function
# ---------------------------
def simulate_send(alert_id):
    """Simulate sending an alert. In real app you'd call SMS/Email/push providers."""
    # For demo: mark as Sent and return a log message
    update_alert_status(alert_id, "Sent")
    return f"Alert {alert_id} marked as Sent (simulated)."

# ---------------------------
# Streamlit UI
# ---------------------------
st.set_page_config(page_title="Emergency Alert System", layout="wide")
st.title("🚨 Emergency Alert System — Prototype")

# Sidebar: quick actions and filters
with st.sidebar:
    st.header("Create New Alert")
    with st.form("create_alert", clear_on_submit=True):
        title = st.text_input("Title", max_chars=80)
        message = st.text_area("Message", help="Explain the emergency and instructions", height=120)
        severity = st.selectbox("Severity", ["Low", "Medium", "High", "Critical"])
        area = st.text_input("Affected Area (city/region)", value="")
        scheduled = st.checkbox("Schedule for later?")
        scheduled_at = None
        if scheduled:
            scheduled_at = st.datetime_input("Schedule time (UTC)", value=datetime.utcnow())
        submitted = st.form_submit_button("Save as Draft")
        if submitted:
            if not title or not message:
                st.error("Please provide both Title and Message.")
            else:
                scheduled_iso = scheduled_at.isoformat() if scheduled_at else None
                alert_id = insert_alert(title, message, severity, area, scheduled_iso, status="Draft")
                st.success(f"Saved as Draft (ID: {alert_id})")
    st.markdown("---")
    st.header("Quick Filters")
    f_severity = st.multiselect("Severity", ["Low","Medium","High","Critical"], default=["High","Critical"])
    f_status = st.multiselect("Status", ["Draft","Sent"], default=["Draft","Sent"])
    f_area = st.text_input("Area contains (optional)")
    st.markdown("Made with Streamlit — single-file prototype")

# Main area: Alerts table and actions
st.header("Alerts Dashboard")

# Build where clause from filters
where_parts = []
params = []
if f_severity:
    where_parts.append("(" + " OR ".join(["severity=?"]*len(f_severity)) + ")")
    params.extend(f_severity)
if f_status:
    where_parts.append("(" + " OR ".join(["status=?"]*len(f_status)) + ")")
    params.extend(f_status)
if f_area:
    where_parts.append("area LIKE ?")
    params.append(f"%{f_area}%")

where_clause = " AND ".join(where_parts) if where_parts else None

alerts_df = fetch_alerts(where_clause, tuple(params))
if alerts_df.empty:
    st.info("No alerts found (try clearing filters).")
else:
    # Show table
    st.write(f"Showing {len(alerts_df)} alerts")
    # Use an interactive table
    st.dataframe(alerts_df[["id","title","severity","area","created_at","scheduled_at","status"]], height=300)

    # Allow selecting an alert to view details and actions
    st.markdown("### Alert Actions")
    sel = st.number_input("Enter alert ID to view / act on", min_value=1, step=1)
    if sel:
        selected = alerts_df[alerts_df["id"] == sel]
        if selected.empty:
            st.warning("No alert with that ID in current list. Make sure it's the correct ID.")
        else:
            row = selected.iloc[0]
            st.subheader(f"{row['title']}  —  {row['severity']}  ({row['status']})")
            st.write("*Message:*")
            st.write(row["message"])
            st.write("*Area:*", row["area"] or "N/A")
            st.write("*Created (UTC):*", row["created_at"])
            st.write("*Scheduled (UTC):*", row["scheduled_at"] or "Not scheduled")
            st.write("---")
            cols = st.columns(3)
            if cols[0].button("Send Now", key=f"send_{sel}"):
                # Check if already sent
                if row["status"] == "Sent":
                    st.info("This alert is already Sent.")
                else:
                    log = simulate_send(sel)
                    st.success(log)
                    # refresh table
                    alerts_df = fetch_alerts(where_clause, tuple(params))
            if cols[1].button("Mark Sent (Manual)", key=f"mark_{sel}"):
                update_alert_status(sel, "Sent")
                st.success(f"Alert {sel} marked Sent.")
                alerts_df = fetch_alerts(where_clause, tuple(params))
            if cols[2].button("Delete (irreversible)", key=f"del_{sel}"):
                c = conn.cursor()
                c.execute("DELETE FROM alerts WHERE id = ?", (sel,))
                conn.commit()
                st.success(f"Alert {sel} deleted.")
                alerts_df = fetch_alerts(where_clause, tuple(params))

# Export & Demo data
st.markdown("---")
st.subheader("Export / Demo")
exp_cols = st.multiselect("Columns to export", options=alerts_df.columns.tolist(), default=["id","title","severity","area","created_at","status"])
if st.button("Export CSV"):
    to_export = alerts_df[exp_cols]
    csv = to_export.to_csv(index=False).encode("utf-8")
    st.download_button("Download CSV", data=csv, file_name="alerts_export.csv", mime="text/csv")

st.write("### Quick demo: create 3 sample alerts")
if st.button("Populate sample alerts"):
    insert_alert("Test: Flood warning", "Heavy rain expected. Move to higher ground.", "High", "Riverside District", None, status="Draft")
    insert_alert("Test: Power outage", "Planned maintenance — expect 4 hours outage.", "Low", "Downtown", None, status="Draft")
    insert_alert("Test: Chemical leak", "Avoid area and follow instructions from authorities.", "Critical", "Industrial Park", None, status="Draft")
    st.success("3 sample alerts inserted.")
    alerts_df = fetch_alerts(where_clause, tuple(params))

# Footer / Notes
st.markdown("---")
st.caption("This is a prototype. Replace simulate_send with real integration to SMS/Email/push (Twilio, AWS SNS, Firebase) for production. All times stored in UTC. Data stored locally in SQLite file alerts.db.")